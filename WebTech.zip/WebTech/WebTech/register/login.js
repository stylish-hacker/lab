document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault(); 
    
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    var registeredUsername = localStorage.getItem("username");
    var registeredPassword = localStorage.getItem("password");

    if (username === registeredUsername && password === registeredPassword) {
        alert("Successfully Logged In");
        
    } else {
        alert("Login Failed. Incorrect username or password.");
    }
});

