document.getElementById("registrationForm").addEventListener("submit", function(event) {
    event.preventDefault(); 
    
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    var email = document.getElementById("email").value;
    var dob = document.getElementById("dob").value;
    var address = document.getElementById("address").value;

    if(password.length<3){
        alert("Set a strong password");
        return;
    }

    localStorage.setItem("username", username);
    localStorage.setItem("password", password);
    localStorage.setItem("email", email);
    localStorage.setItem("dob", dob);
    localStorage.setItem("address", address);

    window.location.href = "login.html";
});